# [randint(0, 100 // 2) for _ in range(100)]
# 1000 loops, best of 5: 50.4 usec per loop
#
# [randint(0, 200 // 2) for _ in range(200)]
# 1000 loops, best of 5: 100 usec per loop

# [randint(0, 400 // 2) for _ in range(400)]
# 1000 loops, best of 5: 202 usec per loop

# [randint(0, 800 // 2) for _ in range(800)]
# 1000 loops, best of 5: 451 usec per loop

