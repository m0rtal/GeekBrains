#!/usr/bin/env python
# coding: utf-8

# # Подготовка данных

# ###Описание датасета
# 
# Id - идентификационный номер квартиры
# 
# DistrictId - идентификационный номер района
# 
# Rooms - количество комнат
# 
# Square - площадь
# 
# LifeSquare - жилая площадь
# 
# KitchenSquare - площадь кухни
# 
# Floor - этаж
# 
# HouseFloor - количество этажей в доме
# 
# HouseYear - год постройки дома
# 
# Ecology_1, Ecology_2, Ecology_3 - экологические показатели местности
# 
# Social_1, Social_2, Social_3 - социальные показатели местности
# 
# Healthcare_1, Helthcare_2 - показатели местности, связанные с охраной здоровья
# 
# Shops_1, Shops_2 - показатели, связанные с наличием магазинов, торговых центров
# 
# Price - цена квартиры

# In[1]:


import numpy as np
import pandas as pd
import scipy

from datetime import datetime

import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import KNNImputer
from sklearn.decomposition import PCA

import warnings
warnings.filterwarnings('ignore')
#get_ipython().run_line_magic('matplotlib', 'inline')
#get_ipython().run_line_magic('config', 'InlineBackend.figure_format = "png"')


# In[2]:


# from google.colab import drive
# drive.mount('/gdrive')
# df = pd.read_csv("/gdrive/My Drive/train.csv")
df = pd.read_csv("train.csv")


# ## Анализ (EDA)

# In[3]:


# с какими признаками придётся работать
print(df.info())


# 1.5 МБ жалко на такое, сразу уменьшим объём памяти и переведём object в category

# In[4]:


# уменьшим объём памяти
def reduce_mem_usage(df):
    """ iterate through all the columns of a dataframe and modify the data type
        to reduce memory usage.        
    """
    start_mem = df.memory_usage().sum() / 1024**2
    print('Memory usage of dataframe is {:.2f} MB'.format(start_mem))
    
    for col in df.columns:
        col_type = df[col].dtype
        
        if col_type != object:
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)  
            else:
                if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float64)
        else:
            df[col] = df[col].astype('category')

    end_mem = df.memory_usage().sum() / 1024**2
    print('Memory usage after optimization is: {:.2f} MB'.format(end_mem))
    print('Decreased by {:.1f}%'.format(100 * (start_mem - end_mem) / start_mem))
    
    return df


# In[5]:


df = reduce_mem_usage(df.drop(["Id"], axis=1).reindex())
print(df.info())


# In[6]:


class DataPipeline:
    """Подготовка исходных данных"""
    
    def __init__(self, df):
        """Параметры класса"""
        # переведём все данные в числовые
        self.df = pd.get_dummies(df, drop_first=True).reindex()
        
    def fit(self):
        """Сохранение статистик"""
        pass
    
    def columns_to_log_normalize(self):
        numZero_tf = dict()
        for col in self.X_train.select_dtypes(exclude="category").columns:
          if min(self.X_train[col])>0:
            numZero_tf[col] = round(scipy.stats.boxcox_normmax(self.X_train[col].loc[self.X_train[col] != 0]),2)
#         test = pd.DataFrame.from_dict(numZero_tf, orient = 'index').T
#         test.rename(index = {0: 'boxCox'}, inplace = True)
#         f, ax = plt.subplots(1,1,figsize = (8,4))
#         sns.barplot(x = test.iloc[0,:], y = test.columns, orient = 'h')
#         ax.axvline(x=0.5, color = 'red')
#         ax.set_xticklabels(test.iloc[0,:])
#         ax.set_title('Lambda BoxCox Plot', fontsize = 14)
#         plt.show()
        return (key for key,value in numZero_tf.items() if value < 0.5)
    
    def log_normalize(self, cols):
        for feature in cols:
            self.X_train[feature] = np.log(self.X_train[feature])
            self.X_test[feature] = np.log(self.X_test[feature])
            
    
    def missing_values(self):
        total = self.df.isnull().sum().sort_values(ascending=False)
        percent = (self.df.isnull().sum()/self.df.isnull().count()).sort_values(ascending=False)
        missing_data = pd.concat([total, percent], axis=1, keys=['Пропуски', 'Процент'])
        print(missing_data)
        return missing_data
    
    def split(self):
        self.data = self.df.drop("Price", axis=1)
        self.target = self.df["Price"]
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(self.data, self.target, test_size=0.3, random_state=42)
        
    def impute(self):
        cols = self.data.columns.to_list()
        imputer = KNNImputer(n_neighbors=5, weights="uniform", add_indicator=True)
        imputed_train = imputer.fit_transform(self.X_train)
        imputed_test = imputer.transform(self.X_test)
        cols_to_add = imputed_train.shape[1] - len(cols)
        cols.extend([f"Missing_{x}" for x in range(cols_to_add)])
        self.X_train = pd.DataFrame(imputed_train, columns=cols)
        self.X_test = pd.DataFrame(imputed_test, columns=cols)
        
    def scale(self):
        scaler = StandardScaler()
        self.X_train = pd.DataFrame(scaler.fit_transform(self.X_train), columns=self.X_train.columns)
        self.X_test = pd.DataFrame(scaler.transform(self.X_test), columns=self.X_test.columns)
        
    def add_pca(self, n):
        pca = PCA(n_components=n)
        pca = pca.fit(self.X_train)
        train_pca = pca.transform(self.X_train)
        test_pca = pca.transform(self.X_test)
        
        cols = (f"PCA_{i}" for i in range(train_pca.shape[1]))
        self.X_train_pca = reduce_mem_usage(pd.DataFrame(train_pca))
        self.X_test_pca = reduce_mem_usage(pd.DataFrame(test_pca))

    
    def cleanup(self):
        """Удаление выбросов"""
        # удалим все выбросы автоматически
        stoplist = ["Ecology_2_B", "Ecology_3_B", "Shops_2_B"]
        for feature in self.df.columns:
            if feature not in stoplist:
                feature_median = self.df[feature].quantile(q=0.5)
                feature_std = self.df[feature].std()
                dist_max = feature_median + feature_std*3
                dist_min = feature_median - feature_std*3
                self.df[feature][(self.df[feature] > dist_max) | (self.df[feature] < dist_min)] = np.nan 
        
    def transform(self):
        """Трансформация данных"""
        
        # 1. Выбросы (outliers)
        self.df["Rooms"][self.df["Rooms"] == 0] = np.nan
        self.df["Square"][self.df["Square"] < 20] = np.nan
        self.df["LifeSquare"][(self.df["LifeSquare"] < 10)] = self.df["LifeSquare"]*10
        self.df["LifeSquare"][(self.df["LifeSquare"] > self.df["Square"]) | (self.df["LifeSquare"] > 120)] = np.nan
        self.df["KitchenSquare"][(self.df["KitchenSquare"] > self.df["Square"]) |                                  (self.df["KitchenSquare"] > self.df["LifeSquare"]) |                                  (self.df["KitchenSquare"] <= 1)] = np.nan
        self.df["Floor"][self.df["Floor"] > self.df["HouseFloor"]] = np.nan
        self.df["HouseFloor"][(self.df["HouseFloor"] == 0)] = np.nan
        self.df["HouseYear"][self.df["HouseYear"] > 2020] = np.nan
        
        missing = self.missing_values()
        self.df.drop(missing[missing["Процент"] > 0.15].index, axis=1, inplace=True)
        
        
        #self.df.drop([])
        
        #df.drop(["Healthcare_1", "LifeSquare", "Floor"], axis=1, inplace=True)
        
        # 2. Заполним пропуски
        
        
        # 3. Новые фичи (features)
        self.df["SquarePerRoom"] = self.df["Square"]/self.df["Rooms"]
        
        # Доля спален в общем кол-ве комнат
        #df['bedroom_share'] = df['total_bedrooms'] / df['total_rooms'] * 100

        # Сколько человек в среднем живут в одной комнате
        #df['population_per_room'] = df['population'] / df['total_rooms']
        
        self.df = self.df[self.df['Price'].notna()]
        
        self.df = reduce_mem_usage(self.df)
        
        self.split()
        self.impute()
        self.log_normalize(self.columns_to_log_normalize())
        self.scale()
        self.add_pca(17) # описывает 90% данных
        


# In[7]:


# посмотрим подробнее на целевую переменную
print(df["Price"].describe())
def deviations(series):
  median = series.quantile(q=0.5)
  avg = series.mean()
  std = series.std()
  mode = series.mode()[0]
  print(f"Медиана со средним значением отличаются на {round(abs(median-avg)/std, 2)} стандартных отклонения")
  if series.min() < median-std*3:
    print(f"Минимальное значение меньше, чем медиана - 3 стандартных отклонения (выходит из 99,7% диапазона данных)")
  if series.max() > median+std*3:
    print(f"Максимальное значение больше, чем медиана + 3 стандартных отклонения (выходит из 99,7% диапазона данных)")
  return median, avg, mode

median, avg, mode = deviations(df["Price"])


# Минимальное значение не меньше нуля, пропусков нет, медиана со средним значением хоть и отличается, но не намного (менее четверти стандартного отклонения), а вот максимальное значение великовато. Посмотрим на график.

# In[8]:


from scipy import stats
sns.set(rc={'figure.figsize':(20,10)})
sns.distplot(df['Price'])
plt.axvline(median, c="red", label="median")
plt.axvline(avg, c="green", label="average")
plt.axvline(mode, c="orange", label="mode")
plt.legend(loc="best", frameon=False)
fig = plt.figure()
res = stats.probplot(df['Price'], plot=plt)


# Распределение отклонено от нормального, длинный хвост больших значений даёт положительную асимметрию, есть пики.

# In[9]:


print(f"Коэффициент асимметрии: {df['Price'].skew():.2f}")
print(f"Коэффициент эксцесса: {df['Price'].kurtosis():.2f}")


# Распределение целевой переменной излишне островершинное и, как отмечалось выше, имеет положительную асимметрию.

# Применим логарифмическое преобразование

# In[10]:


price_log = np.log(df['Price'])
sns.distplot(price_log);
fig = plt.figure()
res = stats.probplot(price_log, plot=plt)


# In[11]:


print(f"Коэффициент асимметрии: {price_log.skew():.2f}")
print(f"Коэффициент эксцесса: {price_log.kurtosis():.2f}")


# ## Анализ признаков

# ### Количественные признаки

# In[12]:


sns.set(rc={'figure.figsize':(15,40)})
numerical_data = df.select_dtypes(exclude="category")
numerical_data.hist(bins=30, grid=False, layout=(-1,2))


# In[13]:


def correlation_matrix(df):
    plt.figure(figsize=(20,20))
    sns.set(font_scale=1.4)
    corr_matrix = df.corr()
    corr_matrix = np.round(corr_matrix, 2)
    corr_matrix[np.abs(corr_matrix)<0.3] = 0
    sns.heatmap(corr_matrix, annot=True, linewidth=.5, cmap="coolwarm")
    plt.title("Матрица корреляции")
    plt.plot()
    # корреляция с целевой переменной
    plt.figure(figsize=(20,20))
    cols = corr_matrix.nlargest(11, 'Price')['Price'].index
    cm = np.corrcoef(corr_matrix[cols].values.T)
    sns.set(font_scale=1.5)
    hm = sns.heatmap(cm, cbar=True, annot=True, square=True, fmt='.2f', annot_kws={'size': 15}, yticklabels=cols.values, xticklabels=cols.values)
    plt.plot()


# In[14]:


def scatter(df, feature):
    if feature != "Price":
        plt.figure(figsize=(20,10))
        plt.scatter(x=df["Price"], y=df[feature], c=df["Price"])
        plt.xlabel("Price")
        plt.ylabel(feature)
        plt.show()
        plt.close()


# Отказался от отрисовки "оптом" - каждый график рассмотрен индивидуально ниже

# ### Категориальные признаки

# In[15]:


def boxplot(df, feature):
    sns.set(rc={'figure.figsize':(20,10)})
    plt.xticks(rotation=45)
    sns.boxplot(df[feature], df['Price'])
    plt.show()


# Отказался от отрисовки "оптом" - каждый график рассмотрен индивидуально ниже

# # Scatterplot

# In[16]:


# sns.set()
# cols = ['Price', 'Rooms', 'Square', 'Social_1', 'Social_2', 'Helthcare_2', 'Shops_1', "HouseFloor"]
# sns.pairplot(df[cols], size = 3)
# plt.show()


# ## Пропуски в данных

# ## Выбросы

# In[17]:


from collections import Counter, defaultdict
def checkOutlier(df, m = 4):
    uniOutlier = dict().fromkeys(df.columns, None)
    outSample = abs(df - df.mean()) > 3 * df.std()
    outSum = (abs(df - df.mean()) > 3 * df.std()).sum()
    for key in uniOutlier.keys():
        uniOutlier[key] = set(outSample.index[outSample.loc[:, key]])
    outportion = outSum / df.shape[0]
    #print("No outlier Vars: " ,outSum.index[outportion == 0].tolist())
    #print("Outlier Portion")
    #print(outportion[outportion != 0].index.tolist())
    #print(outportion[outportion != 0].values.tolist())
    outportion = outportion[outportion != 0].sort_values()
    outlierLst = outportion.index.tolist()
    return uniOutlier, outlierLst

from collections import Counter
def outlierCounter(outlierDict, exceptionLst = ['Price']):
    inter = Counter()
    name = defaultdict(list)
    coreKey = set(outlierDict.keys()).difference(exceptionLst)
    for key in coreKey:
        value = outlierDict[key]
        for val in value:
            inter[val] += 1
            name[val].append(key)
    res = pd.DataFrame([inter, name], index = ['count', 'variable']).T
    res = res.sort_values('count', ascending = False)
    return res


# In[18]:


#print(df.columns)
cols = ['Rooms', 'Square', 'LifeSquare', 'KitchenSquare', 'Floor',
       'HouseFloor', 'HouseYear', 'Ecology_1', 'Social_1', 'Social_2',
       'Social_3', 'Healthcare_1', 'Helthcare_2', 'Shops_1']
uniOutlier, outlierList = checkOutlier(df[cols])
uniOut = outlierCounter(uniOutlier, ['Price'])

uniOut[uniOut['count']>1]


# # Предобработка данных

# In[19]:


data = DataPipeline(df)
data.cleanup()


# In[20]:


# теперь каждый признак индивидуально
data.df["Rooms"].describe()


# Удалим нулевое число комнат

# In[21]:


data.df["Square"].describe()
scatter(data.df, "Square")


# Удалим значения меньше 20

# In[22]:


data.df["LifeSquare"].describe()
scatter(data.df, "LifeSquare")


# Значения меньше 10 умножим на 10, значения больше 120 - удалим

# In[23]:


print(data.df["KitchenSquare"].describe())
scatter(data.df, "KitchenSquare")


# Удалим значения <= 1 и > 30

# In[24]:


print(data.df["Floor"].describe())
boxplot(data.df, "Floor")


# Удалим этаж выше этажности

# In[25]:


boxplot(data.df, "Ecology_2_B")
boxplot(data.df, "Ecology_3_B")
boxplot(data.df, "Shops_2_B")


# Признаки - "никакие", разные группы имеют близкие ценовые диапазоны. Попробуем скомбинировать с другими признаками.

# In[26]:


data.transform()


# ### Посмотрим на матрицу корреляции:

# In[27]:


correlation_matrix(data.df)


# ### Посмотрим на данные в 2D

# In[28]:


from sklearn.manifold import TSNE
tsne = TSNE(n_components = 2, learning_rate=300, random_state=42)
X_train_tsne = tsne.fit_transform(data.X_train)
plt.scatter(X_train_tsne[:, 0], X_train_tsne[:,1])


# In[29]:


from sklearn.cluster import KMeans
model = KMeans(n_clusters=10)
labels_train = model.fit_predict(data.X_train)

plt.scatter(X_train_tsne[:, 0], X_train_tsne[:,1], c=labels_train)


# In[30]:


labels_cluster_train = pd.Series(model.predict(data.X_train), name="Cluster")
cluster_train_dummies = pd.get_dummies(labels_cluster_train, prefix="Cluster")


# In[31]:


labels_cluster_test = pd.Series(model.predict(data.X_test), name="Cluster")
cluster_test_dummies = pd.get_dummies(labels_cluster_test, prefix="Cluster")


# In[35]:


from catboost import CatBoostRegressor
# model = CatBoostRegressor(task_type="GPU",
#                            devices='0:1')
model = CatBoostRegressor(early_stopping_rounds=10,
                          od_type="IncToDec",
                          eval_metric="R2",
                          loss_function="RMSE",
                          depth=6,
                          learning_rate=0.04,
                          l2_leaf_reg=3.6)

from sklearn.feature_selection import RFECV
selector = RFECV(model, step=1, cv=5, n_jobs=-1)
selector = selector.fit(data.X_train, data.y_train)
use_columns = data.X_test.columns[selector.support_]
print(use_columns)

##grid = {'learning_rate': np.arange(0.01,0.05,.01),
##        'depth': np.arange(2,10,2),
##        'l2_leaf_reg': np.arange(0.1,10,0.1)}
##
##grid_search_result = model.grid_search(grid, 
##                                       X=data.X_train, 
##                                       y=data.y_train, 
##                                       cv=5,
##                                       calc_cv_statistics=True,
##                                       search_by_train_test_split=True,
##                                       refit=True,
##                                       shuffle=True,
##                                       train_size=0.8,
##                                       verbose=True,
##                                       plot=True)
##print(grid_search_result[params])
##model.fit(data.X_train, data.y_train)
##
##
### In[ ]:
##
##
##y_pred = model.predict(data.X_test)
##y_pred_train = model.predict(data.X_train)
##
##
### In[ ]:
##
##
##from sklearn.metrics import r2_score
##print("На начальных данных:")
##print("Test:", r2_score(data.y_test, y_pred))
##print("Train: ", r2_score(data.y_train, y_pred_train))
##
##
### In[ ]:
##
##
##train_cluster = pd.concat([data.X_train, cluster_train_dummies], axis=1)
##model.fit(train_cluster, data.y_train)
##
##
### In[ ]:
##
##
##test_cluster = pd.concat([data.X_test, cluster_test_dummies], axis=1)
##y_pred = model.predict(test_cluster)
##y_pred_train = model.predict(train_cluster)
##
##
### In[ ]:
##
##
##print("На начальных данных + кластеры:")
##print("Test:", r2_score(data.y_test, y_pred))
##print("Train: ", r2_score(data.y_train, y_pred_train))
##
##
### In[ ]:
##
##
##pca_cluster_train = pd.concat([data.X_train_pca, cluster_train_dummies], axis=1)
##model.fit(pca_cluster_train, data.y_train)
##
##
### In[ ]:
##
##
##pca_cluster_test = pd.concat([data.X_test_pca, cluster_test_dummies], axis=1)
##y_pred = model.predict(pca_cluster_test)
##y_pred_train = model.predict(pca_cluster_train)
##
##
### In[ ]:
##
##
##print("На PCA данных + кластеры:")
##print("Test:", r2_score(data.y_test, y_pred))
##print("Train: ", r2_score(data.y_train, y_pred_train))
##
##
### In[ ]:
##
##
##
##
